<?php

namespace App\Filters;

class RoleFilter extends FilterRequest
{

}
