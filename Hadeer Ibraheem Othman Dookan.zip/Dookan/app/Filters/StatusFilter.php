<?php

namespace App\Filters;

class StatusFilter extends FilterRequest
{

}
