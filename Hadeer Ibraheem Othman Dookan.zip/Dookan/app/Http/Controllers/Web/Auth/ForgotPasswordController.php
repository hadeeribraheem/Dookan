<?php

namespace App\Http\Controllers\Web\Auth;

use App\Http\Controllers\Controller;

class ForgotPasswordController extends Controller
{
    //
}
