<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('Home.customer_profile.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="section">
        <div class="section-body customer-profile">
            <h2 class="section-title"><?php echo e(__('keywords.hi_user', ['name' => Auth::user()->name])); ?></h2>
            <p class="section-lead"><?php echo e(__('keywords.add_address_info')); ?></p>

            <div class="row mt-sm-4">
                <div class="col-12 col-md-12 col-lg-7">
                    <div class="card">
                        <form method="POST" action="<?php echo e(route('user.address.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-12">
                                        <label for="address_en" class="form-label"><?php echo e(__('keywords.address_english')); ?></label>
                                        <input type="text" class="form-control" id="address_en" name="address_en" required>
                                    </div>
                                    <div class="form-group col-12">
                                        <label for="address_ar" class="form-label"><?php echo e(__('keywords.address_arabic')); ?></label>
                                        <input type="text" class="form-control" id="address_ar" name="address_ar" required>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary ms-auto"><?php echo e(__('keywords.save_changes')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-12 col-lg-5">
                    <?php if(!empty($addressesResource) && count($addressesResource) > 0): ?>
                        <form action="<?php echo e(route('address.select')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <?php $__currentLoopData = $addressesResource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12">
                                        <div class="card mb-3">
                                            <div class="card-body d-flex justify-content-center align-items-center">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="selected_address" id="address_<?php echo e($address['id']); ?>" value="<?php echo e($address['id']); ?>"
                                                           <?php if(Auth::user()->default_address_id == $address['id']): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="address_<?php echo e($address['id']); ?>">
                                                        <strong><?php echo e(__('keywords.address')); ?></strong> <?php echo e($address['address']); ?><br>
                                                    </label>
                                                </div>
                                                <div class="ms-4">
                                                    <a href="/delete-item?model_name=UserAddress&id=<?php echo e($address['id']); ?>" class="trash-icon">
                                                        <i class="far fa-trash-alt"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="address-card-footer">
                                <button type="submit" class="btn btn-primary ms-auto"><?php echo e(__('keywords.select_address')); ?></button>
                            </div>
                        </form>
                    <?php else: ?>
                        <p class="text-danger ms-3"><?php echo e(__('keywords.no_addresses_found')); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/Home/customer_profile/address.blade.php ENDPATH**/ ?>