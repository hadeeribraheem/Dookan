<?php $__env->startSection('title', __('keywords.login')); ?> <!-- Added translation for the title -->
<?php $__env->startSection('content'); ?>

    <div class="container login-container">
        <div class='box'>
            <div class='wave -one'></div>
            <div class='wave -two'></div>
        </div>

        <div class="card login-card shadow-lg">
            <div class="row g-0">
                <a href="?lang=<?php echo e(app()->getLocale() === 'ar' ? 'en' : 'ar'); ?>">
                    <button type="button" class="lang-btn btn btn-primary">
                        <?php echo e(app()->getLocale() === 'ar' ? __('keywords.english') : __('keywords.arabic')); ?>

                    </button>
                </a>
                <!-- Form Section -->
                <div class="col-md-6 login-form-section p-5">
                    <h3 class="card-title mb-4"><?php echo e(__('keywords.login')); ?></h3> <!-- Translated "Login" -->

                    <form method="POST" action="<?php echo e(route('auth.login')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="mb-3">
                            <label for="email" class="form-label"><?php echo e(__('keywords.email_address')); ?></label> <!-- Translated "Email Address" -->
                            <input type="email" class="form-control" id="email" placeholder="<?php echo e(__('keywords.placeholder_email')); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label"><?php echo e(__('keywords.password')); ?></label> <!-- Translated "Password" -->
                            <input type="password" name="password" class="form-control" id="password" placeholder="<?php echo e(__('keywords.placeholder_password')); ?>" required>
                        </div>
                        <!-- Error Message -->
                        <?php if($errors->has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e($errors->first('error')); ?>

                            </div>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary w-100 mb-3"><?php echo e(__('keywords.login')); ?></button> <!-- Translated "Login" button -->
                        <p><a href="#"><?php echo e(__('keywords.forgot_password')); ?></a></p> <!-- Translated "Forgot Password" -->
                        <p><?php echo e(__('keywords.no_account')); ?> <a href="<?php echo e(route('register')); ?>"><?php echo e(__('keywords.sign_up')); ?></a></p> <!-- Translated "Don't have an account? Sign Up" -->
                    </form>
                </div>

                <!-- Illustration Section -->
                <div class="col-md-6 d-flex justify-content-center align-items-center p-5">
                    <img src="<?php echo e(asset('images/designs/loginpage.svg')); ?>" alt="<?php echo e(__('keywords.login_illustration_alt')); ?>" class="login-illustration img-fluid"> <!-- Translated alt text -->
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/auth/login.blade.php ENDPATH**/ ?>