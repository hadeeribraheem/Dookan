<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <?php if(!(isset($productsResource))): ?>
                <div class="d-flex align-items-center justify-content-center flex-column" style="width: 500px; margin: auto;">
                    <p class="text-center text-info fw-bold"><?php echo e(__('keywords.no_products')); ?></p>
                    <img src="<?php echo e(asset('images/no_data.svg')); ?>" alt="<?php echo e(__('keywords.no_products_image_alt')); ?>" class="img-fluid ">
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $productsResource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- product card -->
                    <div class="col-lg-3 col-sm-2 col-12 mb-3">
                        <a href="<?php echo e(route('products.show', $product['id'])); ?>" class="product-card-link">
                            <div class="product-card">
                                <div class="product-image">
                                    <!-- Main image -->
                                    <?php if(isset($product['image'][0])): ?>
                                        <img src="<?php echo e(asset('images/' . $product['image'][0]['name'])); ?>" class="main-image img-fluid" alt="<?php echo e(__('keywords.product_image_alt', ['name' => $product['name']])); ?>">
                                    <?php endif; ?>

                                    <!-- Hover image -->
                                    <?php if(isset($product['image'][1])): ?>
                                        <img src="<?php echo e(asset('images/' . $product['image'][1]['name'])); ?>" class="hover-image img-fluid" alt="<?php echo e(__('keywords.product_hover_image_alt', ['name' => $product['name']])); ?>">
                                    <?php endif; ?>

                                    <div class="product-icons d-flex flex-column">
                                        <a href="<?php echo e(route('products.show', $product['id'])); ?>" class="icon view" data-bs-toggle="tooltip" data-bs-placement="left" title="<?php echo e(__('keywords.show_product', ['name' => $product['name']])); ?>">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>

                                        <?php if(auth()->guard()->check()): ?>
                                            <form action="<?php echo e(route('wishlist.store')); ?>" method="POST" style="display: inline-block; margin: 0 !important;">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
                                                <button type="submit" class="icon wishlist" data-bs-toggle="tooltip" data-bs-placement="left" title="<?php echo e(__('keywords.add_to_wishlist', ['name' => $product['name']])); ?>" style=" border: none;">
                                                    <i class="fa-solid fa-heart"></i>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('login')); ?>" class="icon wishlist" data-bs-toggle="tooltip" data-bs-placement="left" title="<?php echo e(__('keywords.login_to_add_wishlist')); ?>" style=" border: none;">
                                                <i class="fa-solid fa-heart"></i>
                                            </a>
                                        <?php endif; ?>

                                        <?php if(auth()->guard()->check()): ?>
                                            <form action="<?php echo e(route('cart.store')); ?>" method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
                                                <input type="hidden" name="quantity" value="1">
                                                <button type="submit" class="icon" data-bs-toggle="tooltip" data-bs-placement="left" title="<?php echo e(__('keywords.add_to_cart', ['name' => $product['name']])); ?>" style=" border: none;">
                                                    <i class="fa-solid fa-cart-shopping"></i>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('login')); ?>" class="icon" data-bs-toggle="tooltip" data-bs-placement="left" title="<?php echo e(__('keywords.login_to_add_cart')); ?>">
                                                <i class="fa-solid fa-cart-shopping"></i>
                                            </a>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="product-info">
                                    <h5 class="product-category"><?php echo e($product['category_name']); ?></h5>
                                    <h4 class="product-title"><?php echo e($product['name']); ?></h4>
                                    <p class="product-price"><?php echo e($product['price']); ?> $</p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/Home/all_products.blade.php ENDPATH**/ ?>