<aside id="sidebar">
    <div class="d-flex">
        <button class="toggle-btn" type="button">
            <i class="fa-solid fa-cart-shopping"></i>
        </button>
        <div class="sidebar-logo">
            <a href="<?php echo e(route('products.index')); ?>">Dookan</a>
        </div>
    </div>
    <ul class="sidebar-nav">
        <li class="sidebar-item">
            <a href="<?php echo e(route('profile')); ?>" class="sidebar-link">
                <i class="fa-regular fa-user"></i>
                <span><?php echo e(__('keywords.profile')); ?></span>
            </a>
        </li>
        <li class="sidebar-item">
            <a href="#" class="sidebar-link">
                <i class="fa-solid fa-shop"></i>
                <span><?php echo e(__('keywords.orders')); ?></span>
            </a>
        </li>
        <li class="sidebar-item">
            <a href="<?php echo e(route('user.address.create')); ?>" class="sidebar-link">
                <i class="fa-solid fa-location-dot"></i>
                <span><?php echo e(__('keywords.addresses')); ?></span>
            </a>
        </li>
    </ul>
</aside>
<?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/Home/customer_profile/sidebar.blade.php ENDPATH**/ ?>