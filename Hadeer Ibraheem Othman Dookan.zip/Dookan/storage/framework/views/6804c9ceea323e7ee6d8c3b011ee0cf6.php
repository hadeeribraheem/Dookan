<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <h2 class="section-title"><?php echo e(__('keywords.hi', ['name' => Auth::user()->name])); ?> !</h2>
            <p class="section-lead">
                <?php echo e(__('keywords.add_products')); ?>

            </p>

            <div class="row mt-sm-4">
                <div class="col-12 col-md-12 col-lg-7">
                    <div class="card">
                        <form method="post" action="<?php echo e(route('admin.products.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card-header">
                                <h4><?php echo e(__('keywords.add_product')); ?></h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-12">
                                        <label><?php echo e(__('keywords.product_name')); ?></label>
                                        <input class="form-control" name="name" id="name" placeholder="<?php echo e(__('keywords.clear_name_placeholder')); ?>" required>
                                    </div>
                                    <div class="form-group col-12 col-md-4">
                                        <label for="quantity"><?php echo e(__('keywords.quantity')); ?></label>
                                        <input type="number" class="form-control" id="quantity" name="quantity" min="1" required>
                                    </div>
                                    <div class="form-group col-12 col-md-4">
                                        <label for="price"><?php echo e(__('keywords.price')); ?></label>
                                        <input type="number" class="form-control" id="price" name="price" min="1" placeholder="<?php echo e(__('keywords.price_placeholder')); ?>" required>
                                    </div>
                                    <div class="form-group col-12 col-md-4">
                                        <label for="sku"><?php echo e(__('keywords.sku')); ?></label>
                                        <input type="text" class="form-control" id="sku" name="sku" placeholder="<?php echo e(__('keywords.sku_placeholder')); ?>" required>
                                    </div>

                                    <div class="form-group col-12">
                                        <label for="category"><?php echo e(__('keywords.category')); ?></label>
                                        <select name="category_id" id="category" class="form-control" required>
                                            <option value=""><?php echo e(__('keywords.select_category')); ?></option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category['id']); ?>"><?php echo e($category['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-12">
                                        <label><?php echo e(__('keywords.product_description')); ?></label>
                                        <textarea name="description" id="description" class="form-control" rows="4" placeholder="<?php echo e(__('keywords.description_placeholder')); ?>"></textarea>
                                    </div>

                                    <div class="form-group col-12">
                                        <label><?php echo e(__('keywords.images')); ?></label>
                                        <input class="form-control" type="file" name="images[]" accept="images/*" multiple required>
                                    </div>

                                </div>
                            </div>
                            <div class="card-footer text-right">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.add_product_button')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/admin/insert_data/add_product.blade.php ENDPATH**/ ?>