<aside id="sideBar" class="sideBar col-md-2 col-auto min-vh-100">
    <ul class="sideBar-nav">
        <li class="menu-header"><?php echo e(__('keywords.dashboard')); ?></li>
        <li class="nav-item">
            <a href="<?php echo e(route('admin.dashbaord')); ?>" class="nav-link">
                <i class="bi bi-fire"></i>
                <span><?php echo e(__('keywords.dashboard')); ?></span>
            </a>
        </li>

        <li class="menu-header"><?php echo e(__('keywords.design_studio')); ?></li>
        <li class="nav-item">
            <a href="#" class="nav-link collapsed" data-bs-toggle="collapse" data-bs-target="#forms-nav" aria-expanded="false">
                <i class="bi bi-journal-text"></i>
                <span><?php echo e(__('keywords.forms')); ?></span>
                <i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="forms-nav" class="nav-content collapse" data-bs-parent="#sideBar">
                <li>
                    <a href="<?php echo e(route('admin.users.create')); ?>">
                        <i class="bi bi-circle"></i><span><?php echo e(__('keywords.add_user')); ?></span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.categories.create')); ?>">
                        <i class="bi bi-circle"></i><span><?php echo e(__('keywords.add_category')); ?></span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.products.create')); ?>">
                        <i class="bi bi-circle"></i><span><?php echo e(__('keywords.add_product')); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link collapsed" data-bs-toggle="collapse" data-bs-target="#tables-nav" aria-expanded="false">
                <i class="bi bi-layout-text-window-reverse"></i>
                <span><?php echo e(__('keywords.tables')); ?></span>
                <i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="tables-nav" class="nav-content collapse" data-bs-parent="#sideBar">
                <li>
                    <a href="<?php echo e(route('admin.users.index')); ?>">
                        <i class="bi bi-circle"></i><span><?php echo e(__('keywords.show_users')); ?></span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.categories.index')); ?>">
                        <i class="bi bi-circle"></i><span><?php echo e(__('keywords.show_categories')); ?></span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.products.index')); ?>">
                        <i class="bi bi-circle"></i><span><?php echo e(__('keywords.show_products')); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <li class="nav-heading"><?php echo e(__('keywords.pages')); ?></li>
        <li class="nav-item">
            <a href="<?php echo e(route('admin.profile')); ?>" class="nav-link collapsed">
                <i class="bi bi-person"></i>
                <span><?php echo e(__('keywords.profile')); ?></span>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('logout')); ?>" class="nav-link collapsed">
                <i class="bi bi-box-arrow-left text-danger"></i>
                <span class="text-danger"><?php echo e(__('keywords.logout')); ?></span>
            </a>
        </li>
    </ul>
</aside>
<?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>