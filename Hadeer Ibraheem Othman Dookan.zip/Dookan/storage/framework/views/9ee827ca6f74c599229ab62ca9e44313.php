<?php $__env->startSection('content'); ?>

    <div class="datatable-wrapper datatable-loading no-footer sortable searchable fixed-columns dataTable_ms">

        <div class="datatable-container">
            <table id="Data_table" class="table table-striped table-borderless datatable datatable-table">
                <thead>
                <tr>
                    <th><?php echo e(__('keywords.id')); ?></th>
                    <th><?php echo e(__('keywords.name')); ?></th>
                    <th><?php echo e(__('keywords.username')); ?></th>
                    <th><?php echo e(__('keywords.profile_image')); ?></th>
                    <th><?php echo e(__('keywords.email')); ?></th>
                    <th><?php echo e(__('keywords.role')); ?></th>
                    <th><?php echo e(__('keywords.status')); ?></th>
                    <th><?php echo e(__('keywords.actions')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($user['id']); ?></td>
                        <td><?php echo e($user['name']); ?></td>
                        <td><?php echo e($user['username']); ?></td>

                        <td>
                            <?php if(!empty($user['image'])): ?>
                                <img src="<?php echo e(asset('images/'.$user['image']['name'])); ?>" alt="<?php echo e(__('keywords.user_image')); ?>" class="img-fluid w-80">
                            <?php else: ?>
                                <img src="<?php echo e(asset('images/default.png')); ?>" alt="<?php echo e(__('keywords.default_image')); ?>" class="img-fluid rounded-circle w-80" style="width: 150px; height: 150px;">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($user['email']); ?></td>
                        <td><?php echo e($user['role']); ?></td>
                        <td><?php echo e($user['status']); ?></td>
                        <td>
                            <a href="/delete-item?model_name=User&id=<?php echo e($user['id']); ?>" class="btn btn-sm btn-danger rounded-circle m-1">
                                <i class="bi bi-trash3-fill text-white"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/seller/tables/users.blade.php ENDPATH**/ ?>