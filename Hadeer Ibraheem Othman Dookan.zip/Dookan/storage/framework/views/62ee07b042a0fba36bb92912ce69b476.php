<?php $__env->startSection('content'); ?>

    <div class="datatable-wrapper datatable-loading no-footer sortable searchable fixed-columns dataTable_ms">

        
        <form action="<?php echo e(route('admin.users.index')); ?>" method="GET" class="mb-sm-4">
            <div class="row">
                
                <div class="col-md-4">
                    <label for="role"><?php echo e(__('keywords.filter_by_role')); ?></label> <!-- Filter by Role -->
                    <select name="role" id="role" class="form-control">
                        <option value=""><?php echo e(__('keywords.all_roles')); ?></option> <!-- All Roles -->
                        <option value="admin" <?php echo e(request('role') == 'admin' ? 'selected' : ''); ?>><?php echo e(__('keywords.admin')); ?></option> <!-- Admin -->
                        <option value="seller" <?php echo e(request('role') == 'seller' ? 'selected' : ''); ?>><?php echo e(__('keywords.seller')); ?></option> <!-- Seller -->
                        <option value="customer" <?php echo e(request('role') == 'customer' ? 'selected' : ''); ?>><?php echo e(__('keywords.customer')); ?></option> <!-- Customer -->
                    </select>
                </div>

                
                <div class="col-md-4">
                    <label for="status"><?php echo e(__('keywords.filter_by_status')); ?></label> <!-- Filter by Status -->
                    <select name="status" id="status" class="form-control">
                        <option value=""><?php echo e(__('keywords.all_statuses')); ?></option> <!-- All Statuses -->
                        <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>><?php echo e(__('keywords.active')); ?></option> <!-- Active -->
                        <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>><?php echo e(__('keywords.inactive')); ?></option> <!-- Inactive -->
                    </select>
                </div>

                
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary ms-auto w-75"><?php echo e(__('keywords.apply_filter')); ?></button> <!-- Apply Filter -->
                </div>
            </div>
        </form>

        <div class="datatable-container">
            <table id="Data_table" class="table table-striped table-borderless datatable datatable-table">
                <thead>
                <tr>
                    <th><?php echo e(__('keywords.id')); ?></th> <!-- ID -->
                    <th><?php echo e(__('keywords.name')); ?></th> <!-- Name -->
                    <th><?php echo e(__('keywords.username')); ?></th> <!-- Username -->
                    <th><?php echo e(__('keywords.profile_image')); ?></th> <!-- Profile Image -->
                    <th><?php echo e(__('keywords.email')); ?></th> <!-- Email -->
                    <th><?php echo e(__('keywords.role')); ?></th> <!-- Role -->
                    <th><?php echo e(__('keywords.status')); ?></th> <!-- Status -->
                    <th><?php echo e(__('keywords.actions')); ?></th> <!-- Actions -->
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $usersByRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($user['id']); ?></td>
                        <td><?php echo e($user['name']); ?></td>
                        <td><?php echo e($user['username']); ?></td>

                        <td>
                            <?php if(!empty($user['image'])): ?>
                                <img src="<?php echo e(asset('images/'.$user['image']['name'])); ?>" alt="User Image" class="img-fluid w-80">
                            <?php else: ?>
                                <img src="<?php echo e(asset('images/default.png')); ?>" alt="default.png" class="img-fluid rounded-circle w-80" style="width: 150px; height: 150px;">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($user['email']); ?></td>
                        <td><?php echo e($user['role']); ?></td>
                        <td><?php echo e($user['status']); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.users.edit', $user['id'])); ?>" class="btn btn-sm btn-primary rounded-circle m-1">
                                <i class="bi bi-pen-fill text-white"></i>
                            </a>

                            <form action="<?php echo e(route('admin.users.destroy', $user['id'])); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger rounded-circle m-1">
                                    <i class="bi bi-trash3-fill text-white"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/admin/tables/users.blade.php ENDPATH**/ ?>