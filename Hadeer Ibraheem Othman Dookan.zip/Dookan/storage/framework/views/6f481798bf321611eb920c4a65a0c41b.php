<?php $__env->startSection('title', __('keywords.register')); ?> <!-- Translated title -->
<?php $__env->startSection('content'); ?>
    <div class="container register-container">
        <div class='box'>
            <div class='wave -one'></div>
            <div class='wave -two'></div>
        </div>

        <div class="card register-card shadow-lg">
            <div class="row g-0">
                <a href="?lang=<?php echo e(app()->getLocale() === 'ar' ? 'en' : 'ar'); ?>">
                    <button type="button" class="lang-btn btn btn-primary">
                        <?php echo e(app()->getLocale() === 'ar' ? __('keywords.english') : __('keywords.arabic')); ?>

                    </button>
                </a>

                <!-- Form Section -->
                <div class="col-md-6 register-form-section p-5">
                    <h3 class="card-title mb-4"><?php echo e(__('keywords.register')); ?></h3> <!-- Translated "Register" -->

                    <form method="POST" action="<?php echo e(route('auth.register')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="mb-3">
                            <label for="name" class="form-label"><?php echo e(__('keywords.full_name')); ?></label> <!-- Translated "Full Name" -->
                            <input type="text" class="form-control" id="name" placeholder="<?php echo e(__('keywords.placeholder_full_name')); ?>" name="name" value="<?php echo e(old('name')); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger mt-2"> <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="username" class="form-label"><?php echo e(__('keywords.username')); ?></label> <!-- Translated "Username" -->
                            <input type="text" class="form-control" id="username" placeholder="<?php echo e(__('keywords.placeholder_username')); ?>" name="username" value="<?php echo e(old('username')); ?>" required>
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger mt-2"> <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label"><?php echo e(__('keywords.email_address')); ?></label> <!-- Translated "Email Address" -->
                            <input type="email" class="form-control" id="email" placeholder="<?php echo e(__('keywords.placeholder_email')); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger mt-2"> <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="phone" class="form-label"><?php echo e(__('keywords.phone_number')); ?></label> <!-- Translated "Phone Number" -->
                            <input type="tel" class="form-control" id="phone" placeholder="<?php echo e(__('keywords.placeholder_phone')); ?>" name="phone" value="<?php echo e(old('phone')); ?>" required>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger mt-2"> <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label"><?php echo e(__('keywords.password')); ?></label> <!-- Translated "Password" -->
                            <input type="password" name="password" class="form-control" id="password" placeholder="<?php echo e(__('keywords.placeholder_password')); ?>" required>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger mt-2"> <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><?php echo e(__('keywords.image')); ?></label> <!-- Translated "Image" -->
                            <input class="form-control" name="image" type="file">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger mt-2"> <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 mb-3"><?php echo e(__('keywords.register')); ?></button> <!-- Translated "Register" button -->
                        <p><?php echo e(__('keywords.already_have_account')); ?> <a href="<?php echo e(route('login')); ?>"><?php echo e(__('keywords.login_here')); ?></a></p> <!-- Translated "Already have an account? Login here" -->
                    </form>
                </div>

                <!-- Illustration Section -->
                <div class="col-md-6 d-flex justify-content-center align-items-center p-5">
                    <img src="<?php echo e(asset('images/designs/registerpage.svg')); ?>" alt="<?php echo e(__('keywords.register_illustration_alt')); ?>" class="register-illustration img-fluid"> <!-- Translated alt text -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/auth/register.blade.php ENDPATH**/ ?>