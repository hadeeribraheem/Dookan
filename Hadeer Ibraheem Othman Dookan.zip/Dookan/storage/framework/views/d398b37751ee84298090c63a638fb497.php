<?php $__env->startSection('content'); ?>

    <div class="datatable-wrapper datatable-loading no-footer sortable searchable fixed-columns dataTable_ms">

        <div class="datatable-container">
            <table id="Data_table" class="table table-striped table-borderless datatable datatable-table">
                <thead>
                <tr>
                    <th><?php echo e(__('keywords.hash')); ?></th>
                    <th><?php echo e(__('keywords.category_name')); ?></th>
                    <th><?php echo e(__('keywords.description')); ?></th>
                    <th><?php echo e(__('keywords.icon')); ?></th>
                    <th><?php echo e(__('keywords.created_at')); ?></th>
                    <th><?php echo e(__('keywords.actions')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e('#'. $category['id']); ?></td>
                        <td><?php echo e($category['name']); ?></td>
                        <td><?php echo e($category['description']); ?></td>
                        <td><i class="<?php echo e($category['icon']); ?>"></i></td>
                        <td><?php echo e($category['created_at']); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.categories.edit', $category['id'])); ?>" class="btn btn-sm btn-primary rounded-circle m-1">
                                <i class="bi bi-pen-fill text-white"></i>
                            </a>
                            <a href="/delete-item?model_name=Categories&id=<?php echo e($category['id']); ?>" class="btn btn-sm btn-danger rounded-circle m-1">
                                <i class="bi bi-trash3-fill text-white"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/admin/tables/categories.blade.php ENDPATH**/ ?>