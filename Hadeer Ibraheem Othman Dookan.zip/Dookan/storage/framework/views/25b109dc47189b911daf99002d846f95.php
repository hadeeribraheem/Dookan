<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('Home.customer_profile.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="section">
        <div class="section-body customer-profile">
            <h2 class="section-title"><?php echo e(__('keywords.hi_user', ['name' => Auth::user()->name])); ?></h2>
            <p class="section-lead"><?php echo e(__('keywords.change_info')); ?></p>

            <div class="row mt-sm-4">
                <div class="col-12 col-md-12 col-lg-7">
                    <div class="card">
                        <form method="POST" action="<?php echo e(route('update.user', Auth::user()->id)); ?>" enctype="multipart/form-data" class="needs-validation" novalidate="">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-12">
                                        <label><?php echo e(__('keywords.personal_image')); ?></label>
                                        <input class="form-control" type="file" name="personal_image">
                                        <?php if(Auth::user()->image): ?>
                                            <img src="<?php echo e(asset('images/'. Auth::user()->image->name)); ?>" alt="User Image" class="mt-3" style="max-width: 200px;">
                                        <?php else: ?>
                                            <p id="NoImg"><?php echo e(__('keywords.no_image')); ?></p>
                                            <img src="<?php echo e(asset('images/default.png')); ?>" alt="default.png" class="img-fluid rounded-circle" style="width: 150px; height: 150px;">
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-md-6 col-12">
                                        <label><?php echo e(__('keywords.full_name')); ?></label>
                                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->name); ?>" name="name">
                                    </div>
                                    <div class="form-group col-md-6 col-12">
                                        <label><?php echo e(__('keywords.username')); ?></label>
                                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->username); ?>" name="username">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-7 col-12">
                                        <label><?php echo e(__('keywords.email')); ?></label>
                                        <input type="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>" name="email">
                                    </div>
                                    <div class="form-group col-md-5 col-12">
                                        <label><?php echo e(__('keywords.phone')); ?></label>
                                        <input type="tel" class="form-control" value="<?php echo e(Auth::user()->phone); ?>" name="phone">
                                    </div>
                                    <div class="form-group col-12">
                                        <label><?php echo e(__('keywords.password')); ?> <span style="font-size: 0.9em; color: gray; font-style: italic;"><?php echo e(__('keywords.leave_blank')); ?></span></label>
                                        <input class="form-control" type="password" name="password">
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary ms-auto"><?php echo e(__('keywords.save_changes')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/Home/customer_profile/index.blade.php ENDPATH**/ ?>