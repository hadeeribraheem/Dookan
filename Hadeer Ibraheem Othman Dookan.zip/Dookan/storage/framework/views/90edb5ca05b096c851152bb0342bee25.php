<?php $__env->startSection('content'); ?>
    <div class="cart-wrap py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-heading mb-10"><?php echo e(__('keywords.my_wishlist')); ?></div>
                    <?php if(empty($wishlistResource)): ?>
                        <div class="d-flex align-items-center justify-content-center flex-column" style="width: 500px; margin: auto;">
                            <p class="text-center text-info fw-bold mt-5"><?php echo e(__('keywords.empty_wishlist_message')); ?></p>
                            <img src="<?php echo e(asset('images/no_data.svg')); ?>" alt="no products" class="img-fluid" style="height: 80vh; width: 80vh;">
                        </div>
                    <?php else: ?>
                        <div class="table-wishlist table-responsive-sm">
                            <table class="table table-hover text-center">
                                <thead>
                                <tr>
                                    <th class="text-center"><?php echo e(__('keywords.product_image')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.product_name')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.unit_price')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.stock_status')); ?></th>
                                    <th class="text-center"></th>
                                    <th class="text-center"></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $wishlistResource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center align-middle">
                                            <div class="d-flex justify-content-center align-items-center">
                                                <div class="img-product">
                                                    <?php if(isset($wishlist['image'][1])): ?>
                                                        <img src="<?php echo e(asset('images/' . $wishlist['image'][1]['name'])); ?>" class="img-fluid w-50" alt="Product Image" style="max-width: 100px;">
                                                    <?php elseif(isset($wishlist['image'][0])): ?>
                                                        <img src="<?php echo e(asset('images/' . $wishlist['image'][0]['name'])); ?>" class="img-fluid w-50" alt="Product Image" style="max-width: 100px;">
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="name-product text-center align-middle">
                                            <?php echo e($wishlist['name']); ?>

                                        </td>
                                        <td class="price text-center align-middle">
                                            <?php echo e('$'.$wishlist['price']); ?>

                                        </td>
                                        <?php if($wishlist['status']=='1'): ?>
                                            <td class="text-center align-middle"><span class="in-stock-box bg-success"><?php echo e(__('keywords.in_stock')); ?></span></td>
                                        <?php else: ?>
                                            <td class="text-center align-middle"><span class="in-stock-box bg-danger"><?php echo e(__('keywords.out_of_stock')); ?></span></td>
                                        <?php endif; ?>
                                        <td class="text-center align-middle">
                                            <?php if($wishlist['status']=='1'): ?>
                                                <form action="<?php echo e(route('cart.store')); ?>" method="POST" style="display: inline-block;">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="product_id" value="<?php echo e($wishlist['product_id']); ?>">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="round-blue-btn small-btn" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(__('keywords.add_to_cart_btn')); ?>">
                                                        <?php echo e(__('keywords.add_to_cart_btn')); ?>

                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <button type="button" class="round-blue-btn small-btn" disabled data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(__('keywords.out_of_stock_message')); ?>">
                                                    <?php echo e(__('keywords.add_to_cart')); ?>

                                                </button>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center align-middle">
                                            <a href="/delete-item?model_name=Wishlist&id=<?php echo e($wishlist['id']); ?>" class="trash-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(__('keywords.remove_from_wishlist')); ?>">
                                                <i class="far fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/Home/wishlist.blade.php ENDPATH**/ ?>