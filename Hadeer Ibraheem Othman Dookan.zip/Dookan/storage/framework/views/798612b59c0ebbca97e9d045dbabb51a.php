<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <?php if(isset($product)): ?>
                <!-- Images Section -->
                <div class="col-md-5">
                    <div class="product-main-image">
                        <?php if(isset($product['image'][0])): ?>
                            <img  id="mainProductImage" src="<?php echo e(asset('images/' . $product['image'][0]['name'])); ?>" class="main-image img-fluid" alt="<?php echo e(__('keywords.product_image_alt', ['name' => $product['name']])); ?>">
                        <?php endif; ?>
                    </div>
                    <?php if(!empty($product['image'])): ?>
                        <div class="product-thumbnails d-flex">
                            <?php $__currentLoopData = $product['image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset('images/'.$img['name'])); ?>" class="img-fluid" alt="<?php echo e(__('keywords.thumbnail_image_alt', ['name' => $product['name']])); ?>" onclick="changeImage(this)">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <script>
                                function changeImage(element) {
                                    document.getElementById('mainProductImage').src = element.src;
                                }
                            </script>
                        </div>
                    <?php else: ?>
                        <p id="NoImg"><?php echo e(__('keywords.no_images')); ?></p>
                    <?php endif; ?>
                </div>

                <!-- Product Details Section -->
                <div class="col-md-5">
                    <h2><?php echo e($product['name']); ?></h2>
                    <h5 class="product-category"><?php echo e($product['category_name']); ?></h5>
                    <div>
                        <?php if($product['status'] == '1'): ?>
                            <td class="text-center align-middle"><span class="in-stock-box badge bg-success"><?php echo e(__('keywords.in_stock')); ?></span></td>
                        <?php else: ?>
                            <td class="text-center align-middle"><span class="in-stock-box badge bg-danger"><?php echo e(__('keywords.out_of_stock')); ?></span></td>
                        <?php endif; ?>
                    </div>
                    <p class="mt-3">
                        <?php echo e($product['description']); ?>

                    </p>
                    <h3>$<?php echo e($product['price']); ?> / <?php echo e(__('keywords.per_unit')); ?></h3>

                    <div class="mt-3">
                        <?php if($product['status'] == '1'): ?>
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
                                <input type="hidden" id="hidden-quantity-<?php echo e($product['id']); ?>" name="quantity" value="1">
                                <button type="submit" class="round-blue-btn small-btn"><?php echo e(__('keywords.add_to_cart_btn')); ?></button>
                            </form>
                        <?php else: ?>
                            <button class="btn btn-primary" disabled><?php echo e(__('keywords.add_to_cart_btn')); ?></button>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-2">
                    <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('wishlist.store')); ?>" method="POST" style="display: inline-block; margin: 0 !important;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
                            <button type="submit" class="icon wishlist" data-bs-toggle="tooltip" data-bs-placement="left" title="<?php echo e(__('keywords.add_to_wishlist', ['name' => $product['name']])); ?>" style=" border: none;">
                                <i class="fa-solid fa-heart"></i>
                            </button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="icon wishlist" data-bs-toggle="tooltip" data-bs-placement="left" title="<?php echo e(__('keywords.login_to_add_wishlist')); ?>" style=" border: none;">
                            <i class="fa-solid fa-heart"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="d-flex align-items-center justify-content-center flex-column" style="width: 500px; margin: auto;">
                    <p class="text-center text-info fw-bold"><?php echo e(__('keywords.no_product_available')); ?></p>
                    <img src="<?php echo e(asset('images/error.svg')); ?>" alt="<?php echo e(__('keywords.no_product_image_alt')); ?>" class="img-fluid ">
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/Home/show_product.blade.php ENDPATH**/ ?>