<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(empty($cartResource)): ?>
            <div class="d-flex align-items-center justify-content-center flex-column" style="width: 500px; margin: auto;">
                <p class="text-center text-info fw-bold mt-5"><?php echo e(__('keywords.empty_cart_message')); ?></p>
                <img src="<?php echo e(asset('images/no_data.svg')); ?>" alt="no products" class="img-fluid" style="height: 80vh; width: 80vh;">
            </div>
        <?php else: ?>
            <?php
                $totalPrice = 0;
            ?>

            <form id="cartForm" method="POST" action="<?php echo e(route('order.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="card cart-card mt-4">
                    <div class="row">
                        <div class="col-md-8 p-4">
                            <h4 class="mb-4"><b><?php echo e(__('keywords.shopping_cart')); ?></b></h4>

                            <?php $__currentLoopData = $cartResource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row border-top border-bottom py-3">
                                    <div class="row main align-items-center">
                                        <div class="col-2">
                                            <?php if(isset($cart['image'][1])): ?>
                                                <img src="<?php echo e(asset('images/' . $cart['image'][1]['name'])); ?>" class="img-fluid" style="max-width: 100px;" alt="<?php echo e(__('keywords.product_image')); ?>">
                                            <?php elseif(isset($cart['image'][0])): ?>
                                                <img src="<?php echo e(asset('images/' . $cart['image'][0]['name'])); ?>" class="img-fluid" style="max-width: 100px;" alt="<?php echo e(__('keywords.product_image')); ?>">
                                            <?php endif; ?>
                                        </div>
                                        <div class="col">
                                            <div class="row text-muted"><?php echo e($cart['category_name']); ?></div>
                                            <div class="row"><?php echo e($cart['name']); ?></div>
                                        </div>
                                        <div class="col">
                                            <div class="d-flex align-items-center">
                                                <button type="button" class="btn btn-outline-primary btn-sm decrement-btn" data-id="<?php echo e($cart['id']); ?>" data-price="<?php echo e($cart['price']); ?>">-</button>
                                                <input type="text" name="cart_items[<?php echo e($cart['id']); ?>][quantity]" id="quantity-<?php echo e($cart['id']); ?>" value="1" class="border text-center mx-2 quantity-input" style="width: 40px;" readonly>
                                                <input type="hidden" name="cart_items[<?php echo e($cart['id']); ?>][price]" value="<?php echo e($cart['price']); ?>">
                                                <button type="button" class="btn btn-outline-primary btn-sm increment-btn" data-id="<?php echo e($cart['id']); ?>" data-price="<?php echo e($cart['price']); ?>" data-max="<?php echo e($cart['quantity']); ?>">+</button>
                                            </div>
                                        </div>
                                        <div class="col price" id="item-price-<?php echo e($cart['id']); ?>"><?php echo e('$' . number_format($cart['price'], 2)); ?></div>
                                        <div class="col">
                                            <a href="/delete-item?model_name=Cart&id=<?php echo e($cart['id']); ?>" class="trash-icon">
                                                <i class="far fa-trash-alt"></i>
                                            </a>
                                        </div>

                                        <?php
                                            $itemTotal = $cart['price'] * 1;
                                            $totalPrice += $itemTotal;
                                        ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="back-to-shop mt-3">
                                <a href="<?php echo e(route('products.index')); ?>">&leftarrow; <span class="text-muted"><?php echo e(__('keywords.back_to_shop')); ?></span></a>
                            </div>
                        </div>

                        <div class="col-md-4 summary gradient">
                            <h5><b><?php echo e(__('keywords.summary')); ?></b></h5>
                            <hr>
                            <div class="row">
                                <div class="col"><?php echo e(__('keywords.items_count', ['count' => $distinctProductCount])); ?></div>
                                <div class="col text-right">
                                    <span id="total-price" class="ms-4"><?php echo e('$' . number_format($totalPrice, 2)); ?></span>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col"><?php echo e(__('keywords.shipping')); ?></div>
                                <div class="col text-right">
                                    <span class="ms-4"> $5.00</span>
                                </div>
                            </div>
                            <div class="row mt-3" style="border-top: 1px solid rgba(0,0,0,.1); padding: 2vh 0;">
                                <div class="col"><?php echo e(__('keywords.total_price')); ?></div>
                                <div class="col text-right">
                                    <span id="final-price"><?php echo e('$' . number_format(($totalPrice + 5), 2)); ?></span>
                                </div>
                            </div>

                            <button type="button" class="checkout-btn w-100 btn"><?php echo e(__('keywords.checkout')); ?></button>

                            <div class="modal fade" id="addressModal" tabindex="-1" aria-labelledby="addressModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="addressModalLabel"><?php echo e(__('keywords.choose_address')); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php if(!empty($addressesResource) && count($addressesResource) > 0): ?>
                                                <p><?php echo e(__('keywords.select_saved_address')); ?></p>
                                                <?php $__currentLoopData = $addressesResource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="selected_address" id="address_<?php echo e($address['id']); ?>" value="<?php echo e($address['id']); ?>" <?php if(Auth::user()->default_address_id == $address['id']): ?> checked <?php endif; ?>>
                                                        <label class="form-check-label" for="address_<?php echo e($address['id']); ?>">
                                                            <strong><?php echo e(__('keywords.address')); ?>:</strong> <?php echo e($address['address']); ?><br>
                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <p class="text-danger"><?php echo e(__('keywords.no_address')); ?></p>
                                                <div class="mb-3">
                                                    <label for="address_en" class="form-label"><?php echo e(__('keywords.address_en')); ?></label>
                                                    <input type="text" name="address_en" class="form-control" id="address_en" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="address_ar" class="form-label"><?php echo e(__('keywords.address_ar')); ?></label>
                                                    <input type="text" name="address_ar" class="form-control" id="address_ar" required>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('keywords.close')); ?></button>
                                            <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.submit_order')); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.increment-btn').forEach(button => {
                button.onclick = function () {
                    let itemId = this.dataset.id;
                    let itemPrice = parseFloat(this.dataset.price);
                    let maxQuantity = parseInt(this.dataset.max);
                    let quantityInput = document.getElementById('quantity-' + itemId);
                    let currentQuantity = parseInt(quantityInput.value);

                    if (currentQuantity < maxQuantity) {
                        currentQuantity += 1;
                        quantityInput.value = currentQuantity;
                        updateItemTotal(itemId, currentQuantity, itemPrice);
                        updateTotalPrice();
                    }
                };
            });

            document.querySelectorAll('.decrement-btn').forEach(button => {
                button.onclick = function () {
                    let itemId = this.dataset.id;
                    let itemPrice = parseFloat(this.dataset.price);
                    let quantityInput = document.getElementById('quantity-' + itemId);
                    let currentQuantity = parseInt(quantityInput.value);

                    if (currentQuantity > 1) {
                        currentQuantity -= 1;
                        quantityInput.value = currentQuantity;
                        updateItemTotal(itemId, currentQuantity, itemPrice);
                        updateTotalPrice();
                    }
                };
            });

            function updateItemTotal(itemId, quantity, price) {
                let itemPriceElement = document.getElementById('item-price-' + itemId);
                let newItemPrice = quantity * price;
                itemPriceElement.innerText = '$' + newItemPrice.toFixed(2);
            }

            function updateTotalPrice() {
                let total = 0;
                document.querySelectorAll('.price').forEach(function (itemPriceElement) {
                    let price = parseFloat(itemPriceElement.innerText.replace('$', ''));
                    total += price;
                });

                document.getElementById('total-price').innerText = '$' + total.toFixed(2);
                document.getElementById('final-price').innerText = '$' + (total + 5).toFixed(2); // Add shipping
            }

            // Show address modal on checkout
            document.querySelector('.checkout-btn').addEventListener('click', function (e) {
                e.preventDefault();
                let myModal = new bootstrap.Modal(document.getElementById('addressModal'));
                myModal.show();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/Home/cart.blade.php ENDPATH**/ ?>