<?php $__env->startSection('content'); ?>
    <div class="login">
        <div class="container">

            <div class="card login-card">
                <a href="?lang=<?php echo e(app()->getLocale() === 'ar' ? 'en' : 'ar'); ?>">
                    <button type="button" class="lang-btn">
                        <?php echo e(app()->getLocale() === 'ar' ? __('keywords.english') : __('keywords.arabic')); ?>

                    </button>
                </a>
                <div class="login-logo d-flex justify-content-center align-items-center">
                    <i class="bi bi-bag-check-fill"></i>

                </div>
                <h2 class="text-center"><?php echo e(__('keywords.login_page')); ?></h2>
                <form method="post" action="<?php echo e(route('admin.auth.login')); ?>" enctype="multipart/form-data" class="admin-login">
                    <?php echo csrf_field(); ?>
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e(__('keywords.email')); ?></label>
                        <input class="form-control" name="email"
                               value="<?php echo e(old('email')); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(__('keywords.password')); ?></label>
                        <input class="form-control" name="password" type="password">
                    </div>
                    <?php if($errors->has('error')): ?>
                        <div>
                            <p class="alert alert-danger mt-2"><?php echo e($errors->first('error')); ?></p>
                        </div>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.submit')); ?></button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.auth.auth_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>