<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <h2 class="section-title"><?php echo e(__('keywords.hi', ['name' => Auth::user()->name])); ?> !</h2>
            <p class="section-lead">
                <?php echo e(__('keywords.add_users')); ?>

            </p>

            <div class="row mt-sm-4">
                <div class="col-12 col-md-12 col-lg-7">
                    <div class="card">
                        <form method="post" action="<?php echo e(route('admin.users.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card-header">
                                <h4><?php echo e(__('keywords.add_user')); ?></h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-12 col-md-6">
                                        <label><?php echo e(__('keywords.user_name')); ?></label>
                                        <input class="form-control" name="name" id="name" placeholder="<?php echo e(__('keywords.user_name_placeholder')); ?>" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                    <div class="form-group col-12 col-md-6">
                                        <label><?php echo e(__('keywords.username')); ?></label>
                                        <input class="form-control" name="username" id="username" placeholder="<?php echo e(__('keywords.username_placeholder')); ?>" value="<?php echo e(old('username')); ?>" required>
                                    </div>

                                    <div class="form-group col-12 col-md-4">
                                        <label for="email"><?php echo e(__('keywords.email_address')); ?></label>
                                        <input type="email" class="form-control" id="email" name="email"  placeholder="<?php echo e(__('keywords.email_placeholder')); ?>" value="<?php echo e(old('email')); ?>" required>
                                    </div>
                                    <div class="form-group col-12 col-md-4">
                                        <label for="phone"><?php echo e(__('keywords.phone_number')); ?></label>
                                        <input type="tel" class="form-control" id="phone" placeholder="<?php echo e(__('keywords.phone_placeholder')); ?>" name="phone" value="<?php echo e(old('phone')); ?>" required>
                                    </div>
                                    <div class="form-group col-12 col-md-4">
                                        <label for="password"><?php echo e(__('keywords.password')); ?></label>
                                        <input type="password" class="form-control" id="password" name="password"  placeholder="<?php echo e(__('keywords.password_placeholder')); ?>" required>
                                    </div>

                                    <div class="form-group col-12 col-md-6">
                                        <label><?php echo e(__('keywords.user_roles')); ?></label>
                                        <select name="role" id="role" class="form-control" required>
                                            <option value=""><?php echo e(__('keywords.select_roles')); ?></option>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role); ?>"><?php echo e($role); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-12 col-md-6">
                                        <label><?php echo e(__('keywords.user_status')); ?></label>
                                        <select name="status" id="status" class="form-control" required>
                                            <option value=""><?php echo e(__('keywords.select_status')); ?></option>
                                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-12">
                                        <label><?php echo e(__('keywords.images')); ?></label>
                                        <input class="form-control" type="file" name="image">
                                    </div>

                                </div>
                            </div>
                            <div class="card-footer text-right">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.add_user_button')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FCIS\Self study\PHP web Dev\projects\GP DEPI\Dookan\resources\views/admin/insert_data/add_user.blade.php ENDPATH**/ ?>